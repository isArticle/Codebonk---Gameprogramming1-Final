using Microsoft.Xna.Framework;
using System.Collections.Generic;

namespace Codebonk
{
    public class Enemy : Character
    {
        protected Player target;
        private Vector2 knockbackVelocity; 
        private float attackCooldownTimer = 0f;

        public int DamageAmount;

        public Enemy(Vector2 startPos, Player Target, int health, float speed, int damage, Color color) : base(startPos, health, speed)
        {
            target = Target;
            DamageAmount = damage;
            BaseColor = color;           
            FlashColor = Color.Red;   
        }

        public override void Update(GameTime gameTime)
        {
            Update(gameTime, null);

        }
        public virtual void Update(GameTime gameTime, List<Enemy> neighbors)
        {
            base.Update(gameTime);
            float gameUpdate = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (attackCooldownTimer > 0) attackCooldownTimer -= gameUpdate;

            if (knockbackVelocity != Vector2.Zero)
            {
                Position += knockbackVelocity * gameUpdate;
                knockbackVelocity = Vector2.Lerp(knockbackVelocity, Vector2.Zero, GameConfig.EnemyKnockbackFriction * gameUpdate);
                if (knockbackVelocity.Length() < 5f) knockbackVelocity = Vector2.Zero;
                return; 
            }

            if (target == null) return;

            Vector2 totalForce = Vector2.Zero;
            
            // Movement  //
            Vector2 toPlayer = target.Position - this.Position;
            if (toPlayer != Vector2.Zero)
            {
                toPlayer.Normalize();
                totalForce += toPlayer;
            }

            //  Collider  //
            if (neighbors != null)
            {
                Vector2 separation = Vector2.Zero;
                int count = 0;
                foreach (var other in neighbors)
                {
                    if (other == this) continue;
                    float dist = Vector2.Distance(this.Position, other.Position);
                    
                    if (dist < GameConfig.EnemySeparationRadius) 
                    {
                        Vector2 push = this.Position - other.Position;
                        if(push == Vector2.Zero) push = new Vector2(1,0); 
                        push.Normalize();
                        separation += push / (dist + 0.1f); 
                        count++;
                    }
                }
                if (count > 0) totalForce += separation * GameConfig.EnemySeparationForce; 
            }

            if (totalForce != Vector2.Zero)
            {
                totalForce.Normalize();
                Position += totalForce * Speed * gameUpdate;
            }
        }

        public void ApplyKnockback(Vector2 direction, float force)
        {
            if(direction != Vector2.Zero) direction.Normalize();
            knockbackVelocity = direction * force;
        }

        public void AttackCooldown()
        { attackCooldownTimer = GameConfig.EnemyAttackCooldown; }

        public bool CanAttack()
        { return attackCooldownTimer <= 0; }
    }
}