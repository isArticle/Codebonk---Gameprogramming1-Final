using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Codebonk
{
    public class DamagePopup
    {
        public Vector2 Position;
        public string Text;
        public Color Color;
        public bool IsActive = true;
        private float lifeTime = GameConfig.PopupLifeTime;

        public DamagePopup(Vector2 position, string text, Color color)
        {
            Position = position;
            Text = text;
            Color = color;
            Position.X += Game1.Random.Next(-15, 15);
            Position.Y -= 25; 
        }

        public void Update(GameTime gameTime)
        {
            Position.Y -= GameConfig.PopupFloatSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
        
            lifeTime -= (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (lifeTime <= 0) IsActive = false;
        }

        public void Draw(SpriteBatch sb, SpriteFont font)
        {
            if (font == null) return;
            sb.DrawString(font, Text, Position, Color);
        }
    }
}