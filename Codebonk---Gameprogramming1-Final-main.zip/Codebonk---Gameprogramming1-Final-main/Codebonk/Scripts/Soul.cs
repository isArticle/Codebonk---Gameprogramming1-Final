using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Codebonk
{
    public class Soul
    {
        public Vector2 Position;
        public float XpValue = GameConfig.SoulXpValue;
        public Texture2D Texture;
        
        public Soul(Vector2 pos, Texture2D texture) 
        { 
            Position = pos; Texture = texture; 
        }

        public void Update(GameTime gameTime, Vector2 playerPos)
        {
            if (Vector2.Distance(Position, playerPos) < GameConfig.SoulMagnetRange)
            {
                Vector2 direction = playerPos - Position;
                if (direction != Vector2.Zero)
                {
                    direction.Normalize();
                    Position += direction * GameConfig.SoulMoveSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                }
            }
        }

        public void Draw(SpriteBatch sb)
        {
            if (Texture == null) return;
            Vector2 origin = new Vector2(Texture.Width / 2, Texture.Height / 2);
            sb.Draw(Texture, Position, null, Color.Cyan, 0f, origin, 0.6f, SpriteEffects.None, 0f);
        }
    }
}