using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Codebonk
{
    public abstract class Character
    {
        public Vector2 Position;
        public Texture2D Texture;
        public float Speed;
        public int Health;
        public int MaxHealth;

        protected float _flashTimer = 0f;
        public Color BaseColor = Color.White;  
        public Color FlashColor = Color.Red;   

        public Rectangle Bounds
        {
            get
            {
                if (Texture == null) return Rectangle.Empty;
                return new Rectangle(
                    (int)(Position.X - Texture.Width / 2), 
                    (int)(Position.Y - Texture.Height / 2), 
                    Texture.Width, 
                    Texture.Height
                );
            }
        }

        public Character(Vector2 pos, int health, float speed)
        {
            Position = pos;
            Health = health;
            MaxHealth = health; 
            Speed = speed;
        }


        public virtual void TakeDamage(int amount)
        {
            Health -= amount;
            if (Health < 0) Health = 0;
            _flashTimer = 0.15f;
        }

        public void Heal(int amount)
        {
            Health += amount;
            if (Health > MaxHealth) Health = MaxHealth;
        }

        public bool IsDead
        {
            get
            {
                if (Health <= 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public virtual void Update(GameTime gameTime)
        {
            if (_flashTimer > 0)
            {
                _flashTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
            }
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            if (Texture != null && !IsDead)
            {
                Color drawColor = BaseColor;
                if (_flashTimer > 0)
                {
                    drawColor = FlashColor;
                }
                Vector2 origin = new Vector2(Texture.Width / 2, Texture.Height / 2);
                spriteBatch.Draw(Texture, Position, null, drawColor, 0f, origin, 1f, SpriteEffects.None, 0f);
            }
        }
    }
}