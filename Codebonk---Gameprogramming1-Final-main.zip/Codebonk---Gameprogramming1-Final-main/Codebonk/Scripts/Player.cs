using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace Codebonk
{
    public class Player : Character
    {
        public int Level = 1;
        public float XP = 0;
        public float LevelXP = GameConfig.PlayerBaseXPGoal;
        public int Score = 0;

        public int WeaponDamage = GameConfig.PistolDamage; 
        private float WeaponTimer = GameConfig.WeaponCooldown;
        public float DamageMultiplier = GameConfig.DamageMultiplier;
        public float AttackSpeedMultiplier = GameConfig.AttackSpeedMultiplier;

        public bool IsDashing = false;
        public int CurrentDashCharges;
        
        private Vector2 _dashDirection;
        private float _dashTimer = 0f;
        private float _dashRechargeTimer = 0f;
        private KeyboardState _prevKeyboard;

        public Player(Vector2 startPos) : base(startPos, GameConfig.PlayerStartHealth, GameConfig.PlayerSpeed) 
        {
            CurrentDashCharges = GameConfig.PlayerDashMaxCharges; 
        }

        //  saniye başı checker //
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            float gameUpdate = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (WeaponTimer > 0) WeaponTimer -= gameUpdate * AttackSpeedMultiplier;
            
            HandleDashRecharge(gameUpdate);

            if (IsDashing)
                UpdateDashMovement(gameUpdate);
            else
                HandleInputMovement(gameUpdate);
            
            KeepInBounds();
            _prevKeyboard = Keyboard.GetState();
        }

        public override void TakeDamage(int amount)
        {
            if (IsDashing) return;
            base.TakeDamage(amount);
        }

        public void Shoot(Vector2 targetPos, List<Bullet> bullets, Texture2D bulletTexture)
        {
            if (WeaponTimer <= 0)
            {
                WeaponTimer = GameConfig.WeaponCooldown;
                bullets.Add(new Bullet(Position, targetPos, bulletTexture, (int)(WeaponDamage * DamageMultiplier)));
            }
        }

        private void HandleDashRecharge(float dt)
        {
            if (CurrentDashCharges < GameConfig.PlayerDashMaxCharges)
            {
                _dashRechargeTimer -= dt;
                if (_dashRechargeTimer <= 0)
                {
                    CurrentDashCharges++;
                    _dashRechargeTimer = GameConfig.PlayerDashCooldown; 
                }
            }
        }

        private void UpdateDashMovement(float dt)
        {
            Position += _dashDirection * GameConfig.PlayerDashSpeed * dt;
            _dashTimer -= dt;
            if (_dashTimer <= 0) IsDashing = false;
        }

        private void HandleInputMovement(float dt)
        {
            var kstate = Keyboard.GetState();
            Vector2 movement = Vector2.Zero;

            if (kstate.IsKeyDown(Keys.W)) movement.Y -= 1;
            if (kstate.IsKeyDown(Keys.S)) movement.Y += 1;
            if (kstate.IsKeyDown(Keys.A)) movement.X -= 1;
            if (kstate.IsKeyDown(Keys.D)) movement.X += 1;


            if (kstate.IsKeyDown(Keys.Space) && _prevKeyboard.IsKeyUp(Keys.Space) && CurrentDashCharges > 0)
            {
                Vector2 dashDirection;
                if (movement == Vector2.Zero)
                {
                    dashDirection = GetMouseDirection();
                }
                else
                {
                    dashDirection = movement;
                }

                StartDash(dashDirection);
            }

            if (movement != Vector2.Zero)
            {
                movement.Normalize();
                Position += movement * Speed * dt;
            }
        }

        private Vector2 GetMouseDirection()
        {
            var mouse = Mouse.GetState();
            Vector2 dir = new Vector2(mouse.X, mouse.Y) - Position;
            if (dir != Vector2.Zero)
            {
                return Vector2.Normalize(dir);
            }
            else
            {
                return Vector2.Zero;
            }
        }

        private void KeepInBounds()
        {
            Position.X = MathHelper.Clamp(Position.X, 0, GameConfig.ScreenWidth);
            Position.Y = MathHelper.Clamp(Position.Y, 0, GameConfig.ScreenHeight);
        }

        private void StartDash(Vector2 moveDir)
        {
            if (moveDir == Vector2.Zero) moveDir = new Vector2(1, 0); 
            IsDashing = true;
            _dashDirection = moveDir;
            _dashTimer = GameConfig.PlayerDashDuration;
            CurrentDashCharges--;
            if (_dashRechargeTimer <= 0) _dashRechargeTimer = GameConfig.PlayerDashCooldown;
        }

        public void GainXP(float amount) { XP += amount; }

        public void LevelUp()
        {
            Level++;
            XP = 0;
            LevelXP *= GameConfig.LevelUpDifficultyCurve;
            IncreaseMaxHealth((int)(MaxHealth * GameConfig.LevelUpHealPercent)); 
            FullHeal(); 
            DamageMultiplier += GameConfig.LevelUpDamageBonus;
            AttackSpeedMultiplier += GameConfig.LevelUpSpeedBonus;
        }

        public void ApplyWaveBonus()
        {
            IncreaseMaxHealth((int)(MaxHealth * GameConfig.WaveBonusHealPercent));
            DamageMultiplier += GameConfig.WaveBonusDamage;
            AttackSpeedMultiplier += GameConfig.WaveBonusSpeed;
        }

        public void IncreaseMaxHealth(int amount) { MaxHealth += amount; }
        public void FullHeal() { Health = MaxHealth; }
    }
}