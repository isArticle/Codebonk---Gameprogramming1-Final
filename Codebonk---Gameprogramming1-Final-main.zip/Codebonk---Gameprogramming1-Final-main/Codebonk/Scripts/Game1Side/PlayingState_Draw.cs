using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Codebonk
{
    public partial class PlayingState
    {
        // Karakter düşmanlar ve mermileri çizmek // 
        public override void Draw(SpriteBatch spriteBatch)
        {
            foreach (var s in souls)
            {
                s.Draw(spriteBatch);
            }

            foreach (var e in enemies)
            {
                e.Draw(spriteBatch);
            }

            player.Draw(spriteBatch);
            DrawPlayerDashBar(spriteBatch);

            foreach (var b in bullets)
            {
                b.Draw(spriteBatch);
            }

            if (gameFont != null)
            {
                foreach (var p in popups)
                {
                    p.Draw(spriteBatch, gameFont);
                }
            }
            
            DrawUI(spriteBatch);

            if (isPaused)
            {
                DrawPausedScreen(spriteBatch);
            }
        }

        private void DrawPlayerDashBar(SpriteBatch spriteBatch)
        {
            if (player.Texture == null || player.IsDead) return;

            int barWidth = 20;
            int barHeight = 4;
            int gap = 2; 
            
            float startX = player.Position.X - ((barWidth * 2 + gap) / 2); 
            float startY = player.Position.Y + (player.Texture.Height / 2) + 10; 

            // 1. Bar //
            Color color1;
            if (player.CurrentDashCharges >= 1)
            {
                color1 = Color.Cyan;
            }
            else
            {
                color1 = Color.Gray;
            }
            spriteBatch.Draw(uiPixel, new Rectangle((int)startX, (int)startY, barWidth, barHeight), color1);

            // 2. Bar //
            Color color2;
            if (player.CurrentDashCharges >= 2)
            {
                color2 = Color.Cyan;
            }
            else
            {
                color2 = Color.Gray;
            }
            spriteBatch.Draw(uiPixel, new Rectangle((int)(startX + barWidth + gap), (int)startY, barWidth, barHeight), color2);
        }

        // ecs basınca gelen pause ekranı // 
        private void DrawPausedScreen(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(uiPixel, new Rectangle(0, 0, GameConfig.ScreenWidth, GameConfig.ScreenHeight), new Color(0, 0, 0, 180));
            
            int cx = GameConfig.ScreenWidth / 2; 
            int cy = GameConfig.ScreenHeight / 2;
            
            Rectangle box = new Rectangle(cx - 150, cy - 100, 300, 220);
            spriteBatch.Draw(uiPixel, box, Color.DarkSlateGray);
            
            Rectangle menuBtn = new Rectangle(cx - 100, cy - 25, 200, 50);
            Rectangle quitBtn = new Rectangle(cx - 100, cy + 45, 200, 50);
            
            spriteBatch.Draw(uiPixel, menuBtn, Color.Orange);
            spriteBatch.Draw(uiPixel, quitBtn, Color.Red);
            
            DrawCenteredString(spriteBatch, gameFont, "PAUSED", new Rectangle(cx - 100, cy - 90, 200, 30), Color.White);
            DrawCenteredString(spriteBatch, gameFont, "MAIN MENU", menuBtn, Color.White);
            DrawCenteredString(spriteBatch, gameFont, "QUIT", quitBtn, Color.White);
        }

        // ekranda ki barlar ve yazılar // 
        private void DrawUI(SpriteBatch spriteBatch)
        {
            // Can ve XP //
            int barWidth = 300; int barHeight = 25; int startX = 20; int startY = 20;
            
            spriteBatch.Draw(uiPixel, new Rectangle(startX, startY, barWidth + 4, barHeight + 4), Color.Black);
            spriteBatch.Draw(uiPixel, new Rectangle(startX + 2, startY + 2, barWidth, barHeight), Color.Gray);

            float hpRatio = (float)player.Health / player.MaxHealth;
            spriteBatch.Draw(uiPixel, new Rectangle(startX + 2, startY + 2, (int)(barWidth * hpRatio), barHeight), Color.Red);

            int xpY = startY + barHeight + 10; int xpHeight = 15;
            spriteBatch.Draw(uiPixel, new Rectangle(startX, xpY, barWidth + 4, xpHeight + 4), Color.Black);
            spriteBatch.Draw(uiPixel, new Rectangle(startX + 2, xpY + 2, barWidth, xpHeight), new Color(50, 50, 50));

            float xpRatio = player.XP / player.LevelXP; 
            if (xpRatio > 1) xpRatio = 1;
            spriteBatch.Draw(uiPixel, new Rectangle(startX + 2, xpY + 2, (int)(barWidth * xpRatio), xpHeight), Color.Gold);

            // Wave //
            int waveBarW = 400; int waveBarH = 10;
            int waveX = GameConfig.ScreenWidth / 2 - waveBarW / 2; int waveY = 10;
            
            float currentDuration = 120f;
            if (currentWaveIndex < GameConfig.WaveDurations.Length) 
                currentDuration = GameConfig.WaveDurations[currentWaveIndex];
            
            spriteBatch.Draw(uiPixel, new Rectangle(waveX, waveY, waveBarW, waveBarH), Color.Black * 0.5f);
            float timeRatio = waveTimer / currentDuration; 
            if (timeRatio > 1) timeRatio = 1;
            spriteBatch.Draw(uiPixel, new Rectangle(waveX, waveY, (int)(waveBarW * timeRatio), waveBarH), Color.Cyan);

            if (gameFont != null)
            {
                spriteBatch.DrawString(gameFont, $"HP: {player.Health}/{player.MaxHealth}", new Vector2(startX + 5, startY + 2), Color.White);
                spriteBatch.DrawString(gameFont, $"LVL {player.Level}", new Vector2(startX + barWidth + 10, startY + 5), Color.Gold);
                spriteBatch.DrawString(gameFont, $"SCORE: {player.Score}", new Vector2(GameConfig.ScreenWidth - 200, 20), Color.White);
                
                string waveText = $"WAVE {currentWaveIndex + 1}";
                Vector2 waveSize = gameFont.MeasureString(waveText);
                spriteBatch.DrawString(gameFont, waveText, new Vector2(GameConfig.ScreenWidth / 2 - waveSize.X / 2, waveY + 15), Color.White);

                float remainingTime = currentDuration - waveTimer; 
                if (remainingTime < 0) remainingTime = 0;
                
                System.TimeSpan t = System.TimeSpan.FromSeconds(remainingTime);
                string timeStr = $"{t.Minutes:D2}:{t.Seconds:D2}";
                
                Vector2 timeSize = gameFont.MeasureString(timeStr);
                spriteBatch.DrawString(gameFont, timeStr, new Vector2(GameConfig.ScreenWidth / 2 - timeSize.X / 2, waveY + 35), Color.LightGray);
            }
        }

        
    }
}