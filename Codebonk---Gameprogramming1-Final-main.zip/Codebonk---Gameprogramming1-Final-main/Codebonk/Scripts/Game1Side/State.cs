using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace Codebonk
{
    public abstract class State
    {
        protected Game1 maingame;
        protected ContentManager maincontent;

        public State(Game1 game, ContentManager content)
        {
            maingame = game;
            maincontent = content;
        }

        protected Texture2D CreateUIPixel()
        {
            var tex = new Texture2D(maingame.GraphicsDevice, 1, 1);
            tex.SetData(new[] { Color.White });
            return tex;
        }

        protected SpriteFont TryLoadFont(string name)
        {
            try { return maincontent.Load<SpriteFont>(name); } catch { return null; }
        }

        protected static void DrawCenteredString(SpriteBatch spriteBatch, SpriteFont font, string text, Rectangle rect, Color color)
        {
            if (font == null) return;
            Vector2 size = font.MeasureString(text);
            Vector2 pos = new Vector2(rect.X + rect.Width / 2 - size.X / 2, rect.Y + rect.Height / 2 - size.Y / 2);
            spriteBatch.DrawString(font, text, pos, color);
        }

        public abstract void LoadContent();
        public abstract void Update(GameTime gameTime);
        public abstract void Draw(SpriteBatch spriteBatch);
    }
}