using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Codebonk
{
    public class MainMenuState : State
    {
        private SpriteFont font;
        private Texture2D uiPixel;
        private MouseState prevMouse;

        public MainMenuState(Game1 game, ContentManager content) : base(game, content) 
        { 
            prevMouse = Mouse.GetState();
        }
        public override void LoadContent() 
        { 
            font = TryLoadFont("File");
            uiPixel = CreateUIPixel();
        }
        public override void Update(GameTime gameTime) 
        {
            MouseState mouse = Mouse.GetState();

            int cx = GameConfig.ScreenWidth / 2;
            int cy = GameConfig.ScreenHeight / 2;

            Rectangle btnRect = new Rectangle(cx - 150, cy + 50, 300, 80);

            if (mouse.LeftButton == ButtonState.Pressed && prevMouse.LeftButton == ButtonState.Released)
            {
                if (btnRect.Contains(mouse.Position))
                {
                    maingame.ChangeState(new PlayingState(maingame, maincontent)); 
                }
            }

            prevMouse = mouse;
        }


        // butonlar ve yazılar //
        public override void Draw(SpriteBatch spriteBatch) 
        {
            spriteBatch.Draw(uiPixel, new Rectangle(0, 0, GameConfig.ScreenWidth, GameConfig.ScreenHeight), new Color(10, 10, 20));

            int cx = GameConfig.ScreenWidth / 2;
            int cy = GameConfig.ScreenHeight / 2;

            Rectangle titleRect = new Rectangle(cx - 300, cy - 200, 600, 150);
            spriteBatch.Draw(uiPixel, titleRect, Color.DarkSlateBlue);

            Rectangle btnRect = new Rectangle(cx - 150, cy + 50, 300, 80);
            spriteBatch.Draw(uiPixel, btnRect, Color.LimeGreen);

            DrawCenteredString(spriteBatch, font, "Codebonk", titleRect, Color.Cyan);
            DrawCenteredString(spriteBatch, font, "CLICK TO START", btnRect, Color.White);
        }
        
    }
}