using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.Collections.Generic;
using System.IO;

namespace Codebonk
{
    public partial class PlayingState : State
    {
        private Player player;
        private List<Enemy> enemies;
        private List<Bullet> bullets;
        private List<Soul> souls;
        private List<DamagePopup> popups;

        private Texture2D playerTexture, enemyTexture, bulletTexture, soulTexture, uiPixel;
        private Texture2D CSharptexture, Ctexture, C2xPlustexture, Javatexture, JavaScripttexture, DotNettexture, Pyhtontexture;
        private SpriteFont gameFont;

        private float spawnTimer = 0f;
        private int currentWaveIndex = 0;
        private float waveTimer = 0f;

        
        // mouse shoot //
        private MouseState prevMouse;
        private KeyboardState prevKeyboard;
        private bool isPaused = false; 

        public PlayingState(Game1 game, ContentManager content) : base(game, content)
        {
        }


        // asset yükleme //
        public override void LoadContent()
        {
            enemies = new List<Enemy>();
            bullets = new List<Bullet>();
            souls = new List<Soul>();
            popups = new List<DamagePopup>();

            player = new Player(new Vector2(GameConfig.ScreenWidth / 2, GameConfig.ScreenHeight / 2));

            playerTexture = LoadTextureSmart("player", 40, Color.White);
            enemyTexture = LoadTextureSmart("enemy", 40, Color.Red);
            bulletTexture = LoadTextureSmart("bullet", 15, Color.White);
            soulTexture = LoadTextureSmart("soul", 20, Color.Cyan);

            CSharptexture = LoadTextureSmart("CSharp", 40, Color.LimeGreen);
            Ctexture      = LoadTextureSmart("C", 40, Color.Black);
            C2xPlustexture    = LoadTextureSmart("C2xPlus", 40, Color.DarkRed);
            Javatexture   = LoadTextureSmart("Java", 40, Color.White);
            JavaScripttexture     = LoadTextureSmart("JavaScript", 40, Color.Orange);
            DotNettexture = LoadTextureSmart("DotNet", 40, Color.Blue);
            Pyhtontexture = LoadTextureSmart("Pyhton", 40, Color.Yellow);

            gameFont = TryLoadFont("File");

            if (playerTexture != null)
            {
                player.Texture = playerTexture;
            }

            uiPixel = CreateUIPixel();
        }

        // asset yoksa kareler oluşması için //
        private Texture2D LoadTextureSmart(string name, int size, Color fallbackColor)
        {
            try 
            { 
                return maincontent.Load<Texture2D>(name); 
            }
            catch 
            { 
                try 
                { 
                    using (FileStream stream = new FileStream(Path.Combine(maingame.Content.RootDirectory, name + ".png"), FileMode.Open)) 
                    {
                        return Texture2D.FromStream(maingame.GraphicsDevice, stream); 
                    }
                } 
                catch 
                { 
                    Texture2D rect = new Texture2D(maingame.GraphicsDevice, size, size);
                    Color[] data = new Color[size*size];
                    for (int i = 0; i < data.Length; ++i)
                    {
                        data[i] = fallbackColor;
                    }
                    rect.SetData(data);
                    return rect; 
                } 
            }
        }
    }
}