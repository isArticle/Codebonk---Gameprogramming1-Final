using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Codebonk
{
    public class GameOverState : State
    {
        private int finalScore;
        private SpriteFont font;
        private Texture2D uiPixel;
        
        private MouseState prevMouse; 

        public GameOverState(Game1 game, ContentManager content, int score) : base(game, content) 
        { 
            finalScore = score; 
            prevMouse = Mouse.GetState();
        }
        
        public override void LoadContent() 
        { 
            font = TryLoadFont("File");
            uiPixel = CreateUIPixel();
        }

        public override void Update(GameTime gameTime) 
        {
            MouseState mouse = Mouse.GetState();

            int cx = GameConfig.ScreenWidth / 2;
            int cy = GameConfig.ScreenHeight / 2;

            Rectangle retryBtn = new Rectangle(cx - 100, cy + 20, 200, 50);
            Rectangle quitBtn = new Rectangle(cx - 100, cy + 90, 200, 50);

            if (mouse.LeftButton == ButtonState.Pressed && prevMouse.LeftButton == ButtonState.Released)
            {
                if (retryBtn.Contains(mouse.Position))
                {
                    maingame.ChangeState(new PlayingState(maingame, maincontent)); 
                }
                else if (quitBtn.Contains(mouse.Position))
                {
                    maingame.Exit();
                }
            }
            prevMouse = mouse;
        }


        // buton ve yazılar //
        public override void Draw(SpriteBatch spriteBatch) 
        {
            spriteBatch.Draw(uiPixel, new Rectangle(0, 0, GameConfig.ScreenWidth, GameConfig.ScreenHeight), new Color(50, 0, 0, 220));

            int cx = GameConfig.ScreenWidth / 2;
            int cy = GameConfig.ScreenHeight / 2;

            Rectangle box = new Rectangle(cx - 200, cy - 150, 400, 320);
            spriteBatch.Draw(uiPixel, box, Color.Black);

            Rectangle retryBtn = new Rectangle(cx - 100, cy + 20, 200, 50);
            Rectangle quitBtn = new Rectangle(cx - 100, cy + 90, 200, 50);

            spriteBatch.Draw(uiPixel, retryBtn, Color.DarkGreen);
            spriteBatch.Draw(uiPixel, quitBtn, Color.DarkRed);

            string text1 = "GAME OVER";
            string text2 = "SCORE: " + finalScore;

            if (font != null)
            {
                Vector2 size1 = font.MeasureString(text1);
                Vector2 size2 = font.MeasureString(text2);

                spriteBatch.DrawString(font, text1, new Vector2(cx - size1.X / 2, cy - 120), Color.Red);
                spriteBatch.DrawString(font, text2, new Vector2(cx - size2.X / 2, cy - 70), Color.White);
            }

            DrawCenteredString(spriteBatch, font, "RETRY", retryBtn, Color.White);
            DrawCenteredString(spriteBatch, font, "QUIT", quitBtn, Color.White);
        }
        
    }
}