using Microsoft.Xna.Framework;

namespace Codebonk
{
    public static class GameConfig
    {
        // ekran //
        public const int ScreenWidth = 1920;
        public const int ScreenHeight = 1080;
        public const bool IsFullScreen = true;

        // player stats //
        public const int PlayerStartHealth = 100;
        public const float PlayerSpeed = 250f; 
        public const float PlayerHitFlashTime = 0.2f;
        
        // dash info //
        public const float PlayerDashSpeed = 1000f;
        public const float PlayerDashDuration = 0.2f;
        public const float PlayerDashCooldown = 2.0f;
        public const int PlayerDashMaxCharges = 2;

        // level stats //
        public const float PlayerBaseXPGoal = 100f;
        public const float LevelUpDifficultyCurve = 1.2f;
        public const float LevelUpHealPercent = 0.01f;
        public const float LevelUpDamageBonus = 0.08f;
        public const float LevelUpSpeedBonus = 0.05f;
        
        // wave //
        public const float WaveBonusHealPercent = 0.005f;
        public const float WaveBonusDamage = 0.001f;
        public const float WaveBonusSpeed = 0.002f;
        public const float BaseSpawnRate = 1.2f;
        public const float MinSpawnRate = 0.2f;
        public static readonly float[] WaveDurations = { 30f, 45f, 60f, 120f };
        public const int BaseSpawnCount = 1;
        public const int SpawnIncrementPerWave = 1;
        public const int MaxSpawnCount = 10;

        // weapon //
        public const int PistolDamage = 35; 
        public const float WeaponCooldown = 0.4f;
        public const float BulletSpeed = 700f;
        public const float DamageMultiplier = 1.0f;
        public const float AttackSpeedMultiplier = 1.0f;

        // enenmy info //
        public const float SoulXpValue = 10f;       
        public const float SoulMagnetRange = 150f; 
        public const float SoulMoveSpeed = 450f;   
        public const float EnemySeparationRadius = 60f;
        public const float EnemySeparationForce = 15.0f; 
        public const float EnemyKnockbackFriction = 5f; 
        public const float EnemyAttackCooldown = 1.0f;
        public const float EnemyScalePerWave = 0.25f;
        public const float MaxEnemyScaleMultiplier = 3.0f;

        // asset //
        public const float PopupLifeTime = 0.8f;    
        public const float PopupFloatSpeed = 60f; 


        // Enemy Stats //

        // CSharp //
        public const int CSharpHP = 10;
        public const float CSharpSpeed = 200f;
        public const int CSharpDamage = 3;

        // C //
        public const int CHP = 40;
        public const float CSpeed = 180f;
        public const int CDamage = 25;

        // C2xPlus //
        public const int C2HP = 200;
        public const float C2Speed = 40f;
        public const int C2Damage = 30;

        // Java //
        public const int JavaHP = 80;
        public const float JavaSpeed = 110f;
        public const int JavaDamage = 12;

        // JavaScript //
        public const int JavaSHP = 20;
        public const float JavaSSpeed = 160f;
        public const int JavaSDamage = 8;

        // DotNet //
        public const int DotNetHP = 100;
        public const float DotNetSpeed = 60f;
        public const int DotNetDamage = 15;

        // Python //
        public const int PythonHP = 30;
        public const float PythonSpeed = 90f;
        public const int PythonDamage = 5;  
    }
}