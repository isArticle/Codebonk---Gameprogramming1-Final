using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace Codebonk
{
    public partial class PlayingState
    {
        public override void Update(GameTime gameTime)
        {
            var kstate = Keyboard.GetState();
            var mouse = Mouse.GetState();

            if (kstate.IsKeyDown(Keys.Escape))
            {
                if (prevKeyboard.IsKeyUp(Keys.Escape))
                {
                    if (isPaused) isPaused = false;
                    else isPaused = true;
                }
            }

            if (isPaused)
            {
                UpdatePausedInput(mouse);
            }
            else
            {
                UpdateGameLogic(gameTime, mouse);
            }

            prevKeyboard = kstate;
            prevMouse = mouse;
        }

        private void UpdatePausedInput(MouseState mouse)
        {
            int cx = GameConfig.ScreenWidth / 2;
            int cy = GameConfig.ScreenHeight / 2;

            Rectangle menuBtn = new Rectangle(cx - 100, cy - 25, 200, 50);
            Rectangle quitBtn = new Rectangle(cx - 100, cy + 45, 200, 50);

            if (mouse.LeftButton == ButtonState.Pressed)
            {
                if (prevMouse.LeftButton == ButtonState.Released)
                {
                    if (menuBtn.Contains(mouse.Position))
                    {
                        maingame.ChangeState(new MainMenuState(maingame, maincontent));
                    }
                    else
                    {
                        if (quitBtn.Contains(mouse.Position))
                        {
                            maingame.Exit();
                        }
                    }
                }
            }
        }

        // saniye başı her şeyi kontrol // 
        private void UpdateGameLogic(GameTime gameTime, MouseState mouse)
        {
            float gameUpdate = (float)gameTime.ElapsedGameTime.TotalSeconds;
            waveTimer += gameUpdate;

            float currentDuration = 120f;
            if (currentWaveIndex < GameConfig.WaveDurations.Length)
            {
                currentDuration = GameConfig.WaveDurations[currentWaveIndex];
            }

            if (waveTimer >= currentDuration)
            {
                waveTimer = 0;
                currentWaveIndex++;
                player.ApplyWaveBonus(); 
            }

            player.Update(gameTime);
            while (player.XP >= player.LevelXP)
            {
                player.LevelUp();
            }

            if (player.IsDead)
                maingame.ChangeState(new GameOverState(maingame, maincontent, player.Score));

            if (mouse.LeftButton == ButtonState.Pressed)
            {
                player.Shoot(new Vector2(mouse.X, mouse.Y), bullets, bulletTexture);
            }

            for (int i = bullets.Count - 1; i >= 0; i--)
            {
                bullets[i].Update(gameTime);
                if (!bullets[i].IsActive) { bullets.RemoveAt(i); continue; }

                for (int j = enemies.Count - 1; j >= 0; j--)
                {
                    if (bullets[i].Bounds.Intersects(enemies[j].Bounds))
                    {
                        int dmg = (int)(bullets[i].Damage * player.DamageMultiplier);
                        enemies[j].TakeDamage(dmg);
                        enemies[j].ApplyKnockback(bullets[i].Direction, 150f);
                        popups.Add(new DamagePopup(enemies[j].Position, "-" + dmg, Color.Yellow));
                        bullets.RemoveAt(i); 

                        if (enemies[j].IsDead)
                        {
                            souls.Add(new Soul(enemies[j].Position, soulTexture));
                            enemies.RemoveAt(j);
                            player.Score += 100;
                        }
                        break;
                    }
                }
            }

            // düşman sistami  // 
            foreach (var enemy in enemies)
            {
                if (Vector2.Distance(player.Position, enemy.Position) < 50f)
                {
                    if (enemy.CanAttack())
                    {
                        int oldHp = player.Health;
                        player.TakeDamage(enemy.DamageAmount);
                        enemy.AttackCooldown();
                        if (player.Health < oldHp) 
                            popups.Add(new DamagePopup(player.Position, "-" + enemy.DamageAmount, Color.Red));
                        
                        Vector2 push = enemy.Position - player.Position;
                        if (push == Vector2.Zero) push = new Vector2(1, 0);
                        enemy.ApplyKnockback(push, 500f);
                    }
                }
            }

            // XP //
            for (int i = souls.Count - 1; i >= 0; i--)
            {
                souls[i].Update(gameTime, player.Position);
                if (Vector2.Distance(souls[i].Position, player.Position) < 40f)
                {
                    player.GainXP(souls[i].XpValue);
                    souls.RemoveAt(i);
                }
            }

            spawnTimer += gameUpdate;
            float currentSpawnRate = GameConfig.BaseSpawnRate - currentWaveIndex * 0.1f;
            if (currentSpawnRate < GameConfig.MinSpawnRate)
            {
                currentSpawnRate = GameConfig.MinSpawnRate;
            }

            if (spawnTimer >= currentSpawnRate)
            {
                spawnTimer = 0f;
                int spawnCount = GameConfig.BaseSpawnCount + currentWaveIndex * GameConfig.SpawnIncrementPerWave;
                if (spawnCount > GameConfig.MaxSpawnCount) spawnCount = GameConfig.MaxSpawnCount;
                for (int s = 0; s < spawnCount; s++)
                {
                    SpawnEnemyBasedOnWave();
                }
            }

            foreach (var e in enemies)
            {
                e.Update(gameTime, enemies);
            }

            for (int i = 0; i < popups.Count; i++)
            {
                popups[i].Update(gameTime);
            }

            for (int i = popups.Count - 1; i >= 0; i--)
            {
                if (!popups[i].IsActive)
                {
                    popups.RemoveAt(i);
                }
            }
        }

        // düşman spawnı //
        private void SpawnEnemyBasedOnWave()
        {
            int side = Game1.Random.Next(0, 4);
            Vector2 spawnPos = Vector2.Zero;
            int w = GameConfig.ScreenWidth; 
            int h = GameConfig.ScreenHeight;

            if (side == 0) spawnPos = new Vector2(Game1.Random.Next(0, w), -50);
            else if (side == 1) spawnPos = new Vector2(Game1.Random.Next(0, w), h + 50);
            else if (side == 2) spawnPos = new Vector2(-50, Game1.Random.Next(0, h));
            else if (side == 3) spawnPos = new Vector2(w + 50, Game1.Random.Next(0, h));

            int enemyType = Game1.Random.Next(0, 7);
            Enemy newEnemy = null;
            if (enemyType == 0) newEnemy = new CSharp(spawnPos, player);
            else if (enemyType == 1) newEnemy = new C(spawnPos, player);
            else if (enemyType == 2) newEnemy = new C2xPlus(spawnPos, player);
            else if (enemyType == 3) newEnemy = new Java(spawnPos, player);
            else if (enemyType == 4) newEnemy = new JavaScript(spawnPos, player);
            else if (enemyType == 5) newEnemy = new DotNet(spawnPos, player);
            else newEnemy = new Pyhton(spawnPos, player);

            if (newEnemy != null)
            {
                float multiplier = 1f + currentWaveIndex * GameConfig.EnemyScalePerWave;
                if (multiplier > GameConfig.MaxEnemyScaleMultiplier)
                {
                    multiplier = GameConfig.MaxEnemyScaleMultiplier;
                }

                newEnemy.MaxHealth = (int)(newEnemy.MaxHealth * multiplier);
                newEnemy.Health = newEnemy.MaxHealth;
                newEnemy.Speed = newEnemy.Speed * multiplier;
                newEnemy.DamageAmount = (int)(newEnemy.DamageAmount * multiplier);


                if (newEnemy is CSharp)          newEnemy.Texture = CSharptexture;
                else if (newEnemy is C)          newEnemy.Texture = Ctexture;
                else if (newEnemy is C2xPlus)    newEnemy.Texture = C2xPlustexture;
                else if (newEnemy is Java)       newEnemy.Texture = Javatexture;
                else if (newEnemy is JavaScript) newEnemy.Texture = JavaScripttexture;
                else if (newEnemy is DotNet)     newEnemy.Texture = DotNettexture;
                else if (newEnemy is Pyhton)     newEnemy.Texture = Pyhtontexture;
                else

                    newEnemy.Texture = enemyTexture;
                enemies.Add(newEnemy);
            }
        }
    }
}