using Microsoft.Xna.Framework;

namespace Codebonk
{
    // CSharp //
    public class CSharp : Enemy
    {
        public CSharp(Vector2 pos, Player target) : base(pos, target, GameConfig.CSharpHP, GameConfig.CSharpSpeed, GameConfig.CSharpDamage, Color.White) 
        { 
        }
    }

    // C //
    public class C : Enemy
    {
        public C(Vector2 pos, Player target) : base(pos, target, GameConfig.CHP, GameConfig.CSpeed, GameConfig.CDamage, Color.White) 
        { 
        }
    }

    // C2xPlus //
    public class C2xPlus : Enemy
    {
        public C2xPlus(Vector2 pos, Player target) : base(pos, target, GameConfig.C2HP, GameConfig.C2Speed, GameConfig.C2Damage, Color.White) 
        { 
        }
    }

    // Java //
    public class Java : Enemy
    {
        public Java(Vector2 pos, Player target) : base(pos, target, GameConfig.JavaHP, GameConfig.JavaSpeed, GameConfig.JavaDamage, Color.White) 
        { 
        }
    }

    // JavaScript //
    public class JavaScript : Enemy
    {
        public JavaScript(Vector2 pos, Player target) : base(pos, target, GameConfig.JavaSHP, GameConfig.JavaSSpeed, GameConfig.JavaSDamage, Color.White) 
        { 
        }
    }

    // DotNet //
    public class DotNet : Enemy
    {
        public DotNet(Vector2 pos, Player target) : base(pos, target, GameConfig.DotNetHP, GameConfig.DotNetSpeed, GameConfig.DotNetDamage, Color.White) 
        { 
        }
    }

    // Pyhton //
    public class Pyhton : Enemy
    {
        public Pyhton(Vector2 pos, Player target) : base(pos, target, GameConfig.PythonHP, GameConfig.PythonSpeed, GameConfig.PythonDamage, Color.White) 
        { 
        }
    }
}