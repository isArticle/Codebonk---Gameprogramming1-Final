using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Codebonk
{
    public class Bullet
    {
        public Vector2 Position;
        public Vector2 Direction;
        public float Speed;
        public Texture2D Texture;
        public bool IsActive = true;
        public int Damage; 

        public Rectangle Bounds 
        {
            get 
            {
                int w;
                if (Texture != null)
                {
                    w = Texture.Width;
                }
                else
                {
                    w = 12;
                }

                int h;
                if (Texture != null)
                {
                    h = Texture.Height;
                }
                else
                {
                    h = 12;
                }
                 return new Rectangle
                (
                    (int)(Position.X - w / 2), 
                    (int)(Position.Y - h / 2), 
                    w, 
                    h
                );
            }
        }

        public Bullet(Vector2 startPos, Vector2 targetPos, Texture2D texture, int damage)
        {
            Position = startPos;
            Texture = texture;
            Damage = damage;
            Speed = GameConfig.BulletSpeed;
            
            Direction = targetPos - startPos;
            if (Direction != Vector2.Zero) Direction.Normalize();
        }

        public void Update(GameTime gameTime)
        {
            Position += Direction * Speed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (Position.X < -100)
            {
                IsActive = false;
            }
            else if (Position.X > GameConfig.ScreenWidth + 100)
            {
                IsActive = false;
            }
            else if (Position.Y < -100)
            {
                IsActive = false;
            }
            else if (Position.Y > GameConfig.ScreenHeight + 100)
            {
                IsActive = false;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (Texture == null) return;
            Vector2 origin = new Vector2(Texture.Width / 2, Texture.Height / 2);
            spriteBatch.Draw(Texture, Position, null, Color.White, 0f, origin, 1f, SpriteEffects.None, 0f);
        }
    }
}